import * as yup from 'yup'

export const FormValidations = yup.object().shape({
    name: yup
      .string()
      .required('Name is required'),
    cpf: yup
      .string()
      .required('Cpf is required'),
    email: yup
      .string()
      .email("E-mail is invalid")
      .required('E-mail is required'),
    telefone: yup
      .string()
      .required('Telefone is required')
})