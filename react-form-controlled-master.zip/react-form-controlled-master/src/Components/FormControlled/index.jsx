import React, { useState, useEffect } from "react";
import Input from "./Input";
import {FormValidations} from './index.validations'
import useValidation from './../../hooks/useValidation'

const initialFormState = {
   name:'',
   cpf: '',
   email:'',
   telefone:''
}

const UserForm = () => {

   const [form, setForm] = useState(initialFormState)
   const {errors} = useValidation(form, FormValidations)
   
   const setInput = (newValue)=>{
      setForm(form => ({...form, ...newValue}))
   }

   return (
      <>
         <h3>Form Controlled</h3>
         <form>
               <div className="form-group">
                  <Input
                     name="name"
                     onChange={e => setInput({ name: e.target.value })}
                     label="Name"
                     value={form.name}
                     error={errors.name}
                  />
               </div>
               <div className="form-group">
                  <Input
                     name="cpf"
                     onChange={e => setInput({ cpf: e.target.value })}
                     label="cpf"
                     value={form.cpf}
                     error={errors.cpf}
                  />
               </div>
               <div className="form-group">
                  <Input
                     name="email"
                     onChange={e => setInput({ email: e.target.value })}
                     label="E-mail"
                     value={form.email}
                     error={errors.email}
                  />
               </div>
               <div className="form-group">
                  <Input
                     name="telefone"
                     onChange={e => setInput({ telefone: e.target.value })}
                     label="telefone"
                     value={form.telefone}
                     error={errors.telefone}
                  />
               </div>

               <div className="form-group">
                  <button type="button" className="btn btn-primary">Submit</button>
               </div>
         </form>
      </>
   );
}

export default UserForm;